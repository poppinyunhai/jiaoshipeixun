require 'test_helper'

class Admin::TicketsHelperTest < ActionView::TestCase
end
