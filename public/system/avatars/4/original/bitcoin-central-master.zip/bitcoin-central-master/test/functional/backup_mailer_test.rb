require 'test_helper'

class BackupMailerTest < ActionMailer::TestCase
end
