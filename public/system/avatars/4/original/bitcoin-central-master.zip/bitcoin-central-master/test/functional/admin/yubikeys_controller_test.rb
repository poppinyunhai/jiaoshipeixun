require 'test_helper'

class Admin::YubikeysControllerTest < ActionController::TestCase
end
