require 'test_helper'

class StaticPageTest < ActiveSupport::TestCase
end
