require 'test_helper'

class Admin::AnnouncementsHelperTest < ActionView::TestCase
end
