require 'test_helper'

class TransfersHelperTest < ActionView::TestCase
end
