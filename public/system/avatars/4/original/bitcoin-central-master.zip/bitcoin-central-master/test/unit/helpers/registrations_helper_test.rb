require 'test_helper'

class RegistrationsHelperTest < ActionView::TestCase
end
