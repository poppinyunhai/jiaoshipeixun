require 'test_helper'

class Admin::InformationsControllerTest < ActionController::TestCase
end
