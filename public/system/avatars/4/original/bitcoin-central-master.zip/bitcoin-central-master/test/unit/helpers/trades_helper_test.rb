require 'test_helper'

class TradesHelperTest < ActionView::TestCase
end
