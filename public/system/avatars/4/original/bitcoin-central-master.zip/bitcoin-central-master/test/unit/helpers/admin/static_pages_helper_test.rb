require 'test_helper'

class Admin::StaticPagesHelperTest < ActionView::TestCase
end
