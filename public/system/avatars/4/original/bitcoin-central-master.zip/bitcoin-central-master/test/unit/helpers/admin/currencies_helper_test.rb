require 'test_helper'

class Admin::CurrenciesHelperTest < ActionView::TestCase
end
