require 'test_helper'

class Admin::InformationsHelperTest < ActionView::TestCase
end
