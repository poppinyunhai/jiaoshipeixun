require 'test_helper'

class CurrencyTest < ActiveSupport::TestCase
end
