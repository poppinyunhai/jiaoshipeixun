require 'test_helper'

class CommentTest < ActiveSupport::TestCase
end
