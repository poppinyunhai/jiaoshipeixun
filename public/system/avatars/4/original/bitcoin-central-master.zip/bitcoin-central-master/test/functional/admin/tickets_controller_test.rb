require 'test_helper'

class Admin::TicketsControllerTest < ActionController::TestCase
end
