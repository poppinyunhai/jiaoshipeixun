require 'test_helper'

class Admin::PendingTransfersControllerTest < ActionController::TestCase
end
