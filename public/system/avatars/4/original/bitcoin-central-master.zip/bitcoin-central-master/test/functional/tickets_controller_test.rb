require 'test_helper'

class TicketsControllerTest < ActionController::TestCase
end
