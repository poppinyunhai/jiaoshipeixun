require 'test_helper'

class Admin::YubikeysHelperTest < ActionView::TestCase
end
