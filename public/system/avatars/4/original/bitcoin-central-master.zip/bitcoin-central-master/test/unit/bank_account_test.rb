require 'test_helper'

class BankAccountTest < ActiveSupport::TestCase
end
