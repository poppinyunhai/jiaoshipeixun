require 'test_helper'

class UserMailerTest < ActionMailer::TestCase
end
