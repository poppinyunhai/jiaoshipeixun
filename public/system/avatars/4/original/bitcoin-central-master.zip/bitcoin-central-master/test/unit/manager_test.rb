require 'test_helper'

class ManagerTest < ActiveSupport::TestCase
end
