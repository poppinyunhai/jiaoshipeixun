require 'test_helper'

class YubikeysHelperTest < ActionView::TestCase
end
