require 'test_helper'

class TicketTest < ActiveSupport::TestCase
end
