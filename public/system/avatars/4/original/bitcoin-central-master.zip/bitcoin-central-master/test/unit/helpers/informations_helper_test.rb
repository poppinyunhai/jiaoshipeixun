require 'test_helper'

class InformationsHelperTest < ActionView::TestCase
end
