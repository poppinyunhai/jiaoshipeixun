require 'test_helper'

class BankAccountsHelperTest < ActionView::TestCase
end
