require 'test_helper'

class Admin::CurrenciesControllerTest < ActionController::TestCase
end
