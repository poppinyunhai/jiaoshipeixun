require 'test_helper'

class BitcoinWithdrawalsHelperTest < ActionView::TestCase
end
