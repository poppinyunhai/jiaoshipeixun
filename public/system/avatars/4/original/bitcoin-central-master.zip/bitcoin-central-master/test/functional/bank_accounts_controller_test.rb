require 'test_helper'

class BankAccountsControllerTest < ActionController::TestCase
end
