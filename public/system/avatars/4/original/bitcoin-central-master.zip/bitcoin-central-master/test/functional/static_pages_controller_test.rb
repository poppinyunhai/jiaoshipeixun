require 'test_helper'

class StaticPagesControllerTest < ActionController::TestCase
end
