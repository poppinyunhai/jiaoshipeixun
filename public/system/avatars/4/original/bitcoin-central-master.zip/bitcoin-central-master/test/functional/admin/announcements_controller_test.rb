require 'test_helper'

class Admin::AnnouncementsControllerTest < ActionController::TestCase
end
