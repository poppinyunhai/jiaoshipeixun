require 'test_helper'

class UsedCurrencyTest < ActiveSupport::TestCase
end
