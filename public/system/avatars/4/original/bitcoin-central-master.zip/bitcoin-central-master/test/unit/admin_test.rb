require 'test_helper'

class AdminTest < ActiveSupport::TestCase
end
