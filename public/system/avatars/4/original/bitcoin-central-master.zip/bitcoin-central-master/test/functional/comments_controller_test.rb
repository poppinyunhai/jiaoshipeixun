require 'test_helper'

class CommentsControllerTest < ActionController::TestCase
end
