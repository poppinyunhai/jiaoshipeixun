require 'test_helper'

class TradeOrdersHelperTest < ActionView::TestCase
end
