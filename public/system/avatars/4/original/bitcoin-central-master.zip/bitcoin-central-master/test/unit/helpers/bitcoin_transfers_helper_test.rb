require 'test_helper'

class BitcoinTransfersHelperTest < ActionView::TestCase
end
