require 'test_helper'

class YubikeysControllerTest < ActionController::TestCase
end
