require 'test_helper'

class Admin::PendingTransfersHelperTest < ActionView::TestCase
end
