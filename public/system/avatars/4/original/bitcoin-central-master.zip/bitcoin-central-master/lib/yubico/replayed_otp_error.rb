module Yubico
  class ReplayedOTPError < StandardError; end
end