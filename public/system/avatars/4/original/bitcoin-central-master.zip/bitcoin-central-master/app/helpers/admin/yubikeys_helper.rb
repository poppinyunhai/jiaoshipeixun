module Admin::YubikeysHelper
end
