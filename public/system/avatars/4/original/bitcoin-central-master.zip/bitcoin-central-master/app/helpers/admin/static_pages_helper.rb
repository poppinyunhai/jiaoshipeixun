module Admin::StaticPagesHelper
end
