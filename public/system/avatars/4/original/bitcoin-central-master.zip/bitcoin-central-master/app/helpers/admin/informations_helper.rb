module Admin::InformationsHelper
end
