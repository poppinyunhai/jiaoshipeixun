BitcoinBank::Application.config.session_store :active_record_store, 
  :key => "bc-session",
  :domain => :all
