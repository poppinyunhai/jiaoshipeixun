# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BitcoinBank::Application.config.secret_token = '1c8d72f49c79fbecef27d20efokzegjeznze654zef2zef651dcdv54dfv21v6582247d5434054bb33864d5e2c06fc89cb6b6e48682d7b40a39042cbbedbf9f0a5'
