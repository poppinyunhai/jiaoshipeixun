class DropAdminFlag < ActiveRecord::Migration
  def self.up
    remove_column :accounts, :admin
  end

  def self.down
    add_column :accounts, :admin, :boolean, :default => false
  end
end
